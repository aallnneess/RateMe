import {Component, inject, OnInit} from '@angular/core';
import {FormBuilder, FormGroup, Validators} from "@angular/forms";

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrl: './login.component.css'
})
export class LoginComponent implements OnInit {

  loginForm!: FormGroup;
  fb: FormBuilder = inject(FormBuilder);

  ngOnInit(): void {
    this.loginForm = this.fb.group({
      'username': ['', [Validators.required, Validators.minLength(3), Validators.pattern('^[a-zA-Z0-9]+$\n')]],
      'password' : ['', [Validators.required, Validators.minLength(8), Validators.pattern('^[a-zA-Z0-9]+$\n')]]
    });
  }


  login() {

  }
}
