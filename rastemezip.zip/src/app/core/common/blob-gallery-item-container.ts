import {GalleryItem} from "ng-gallery";

export class BlobGalleryItemContainer {
  blob!: Blob;
  galleryItem!: GalleryItem;
  // galleryItem!: GalleryItemCustom;
  bucketDocumentId!: string;
}
