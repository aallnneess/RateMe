import {Rate} from "./rate";

export class RateContainer {
  documents: Rate[] = [];
  total: number = 0;
}
