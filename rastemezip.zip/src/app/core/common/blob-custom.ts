export class BlobCustom extends Blob {
  bucketDocumentId!: string;
  userId!: string;
  username!: string;
}
